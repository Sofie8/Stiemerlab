#
# originally by Sofie Thijs
# sofie.thijs@uhasselt.be
#


## Load libraries
library(ggplot2)
library(scales)
library(grid)
library(RColorBrewer)
library(dplyr)

# plotting colors
alpha <- .7
c_yellow <-          rgb(255 / 255, 255 / 255,   0 / 255, alpha)
c_blue <-            rgb(  0 / 255, 000 / 255, 255 / 255, alpha)
c_orange <-          rgb(255 / 255,  69 / 255,   0 / 255, alpha)
c_green <-           rgb(  50/ 255, 220 / 255,  50 / 255, alpha)
c_dark_green <-      rgb( 50 / 255, 200 / 255, 100 / 255, alpha)
c_very_dark_green <- rgb( 50 / 255, 150 / 255, 100 / 255, alpha)
c_sea_green <-       rgb( 46 / 255, 129 / 255,  90 / 255, alpha)
c_black <-           rgb(  0 / 255,   0 / 255,   0 / 255, alpha)
c_grey <-            rgb(180 / 255, 180 / 255,  180 / 255, alpha)
c_dark_brown <-      rgb(101 / 255,  67 / 255,  33 / 255, alpha)
c_red <-             rgb(200 / 255,   0 / 255,   0 / 255, alpha)
c_dark_red <-        rgb(255 / 255, 130 / 255,   0 / 255, alpha)


# Custom colors for barcharts
mycolorscheme_1 <- c("#DA5724","#CBD588", "orange", "#508578", "#CD9BCD","#332288",
			  "#AD6F3B", "#673770","#D14285", "#652926", "#C84248","#5F7FC7",
			  "#6699CC", "#88CCEE", "#44AA99", "#117733","#999933","#DDCC77",
			  "#661100", "#CC6677", "#AA4466", "#882255", "#AA4499","#A3C3D9")


# Plotting themes
main_theme <- theme(panel.background=element_blank(),
              panel.grid=element_blank(),
              axis.line.x=element_line(color="black"),
              axis.line.y=element_line(color="black"),
              axis.ticks=element_line(color="black"),
              axis.text=element_text(colour="black", size=10),
              legend.position="top",
              legend.background=element_blank(),
              legend.key=element_blank(),
              text=element_text(family="sans"))
			  
			  			  
grey_theme <- 	theme(axis.title.x = element_blank(),
				panel.border = element_rect(colour = "black", fill=NA),
				strip.background = element_rect(color = "black"),
				axis.text.x=element_text(angle=45, hjust=1),
				text = element_text(size=14, family="sans"),
				plot.title = element_text(hjust = 0.5),
				axis.line = element_line(colour = "black"),
				plot.margin = margin(1, 1, 1, 1, "cm"))
				
white_theme <- theme(panel.background=element_blank(),
              panel.grid=element_blank(),
              axis.line.x=element_line(color="black"),
              axis.line.y=element_line(color="black"),
              axis.ticks=element_line(color="black"),
              axis.text=element_text(colour="black", size=12),
			  panel.border = element_rect(colour = "black", fill=NA),
			  strip.background = element_rect(color = "black", fill=NA),
			  axis.text.x=element_text(angle=45, hjust=1),
			  text = element_text(size=14, family="sans"),
			  plot.title = element_text(hjust = 0.5),
			  plot.margin = margin(1, 1, 1, 1, "cm"))
			  
bw_theme <- theme(panel.background=element_blank(),
              panel.grid.major=element_line(color="grey92"),
              axis.line.x=element_line(color="black"),
              axis.line.y=element_line(color="black"),
              axis.ticks=element_line(color="black"),
              axis.text=element_text(colour="black", size=12),
			  panel.border = element_rect(colour = "black", fill=NA),
			  strip.background = element_rect(color = "black", fill=NA),
			  axis.text.x=element_text(angle=45, hjust=1),
			  text = element_text(size=15, family="sans"),
			  plot.title = element_text(hjust = 0.5),
			  plot.margin = margin(1, 1, 1, 1, "cm"))



			  


