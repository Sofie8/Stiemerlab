#########################################
###### ui.R web app for GeneralR  #######
#########################################

# Load libraries
library(shiny)
library(tinytex)
library(yaml)
library(rmarkdown)
library(fs)
library(icesTAF)

# If you want to write to a non-temp dir, than change tempdir() by your own directory
tdir = tempdir()
rdir = paste(tdir,"\\Results",sep = "")
if(dir.exists(rdir) == TRUE){unlink(paste(rdir,"\\",dir(rdir), sep = ""))}else{dir.create(rdir)}

adir = paste(tdir,"\\Accessories",sep = "")
if(dir.exists(adir) == TRUE){unlink(paste(adir,"\\",dir(adir), sep = ""))}else{dir.create(adir)}

# useful repositories
# https://github.com/rstudio/rmarkdown/issues/646 (pdf line break problem)
# https://stackoverflow.com/questions/43195871/adjusting-figure-margins-in-rmarkdown

ui<-fluidPage(fileInput('uploadmap', NULL, buttonLabel = "Upload data table:"),
              fileInput('uploadconfig', NULL, buttonLabel = "Upload config file"),
              tableOutput("filesmap"),
              selectInput("metadata", "Which script you want to run:", choices = NULL, multiple = FALSE), #https://stackoverflow.com/questions/38852916/shiny-selecting-specific-columns-from-uploaded-data-frame/38854645
              tableOutput("table_displaymap"),
              downloadButton("reportpdf", "Generate pdf report"),
              #downloadButton("reporthtml", "Generate html report"),
              downloadButton("files_zip_button", "Download figures as zip file"),
)


server <- function(input, output, session) {
  
  # Upload ---------------------------------------------------------
  
  rawmap <- reactive({
    uploadmap <- input$uploadmap
    if (is.null(uploadmap))
      return(NULL)
    m <- read.csv(uploadmap$datapath, sep = '\t') # removed unneccesary arguments, header=input$header, sep=input$sep, quote=input$quote
    varsmap <- c("Load", "Boxplots", "Lineplots", "Barplots", "Dotcharts", "StackedBarArea")
    #Update select input immediately after clicking on the action button. 
    updateSelectInput(session, "metadata","Which script you want to run:", choices = varsmap)
    m
  }) 
  
  rawconfig <- reactive({
   uploadconfig <- input$uploadconfig
   if (is.null(uploadconfig))
     return(NULL)
   config <- yaml.load_file(uploadconfig$datapath)
   })  
  
  #output ---------------------------------------------------------
  output$filesmap <- renderTable(input$uploadmap)
  
  output$table_displaymap <- renderTable({
    m <- rawmap()
    #m <- subset(m, select = input$metadata) #subsetting takes place here
    head(m)
  })
  
  # Download -------------------------------------------------------
    
  # if selectinput changes, update output
  output$reportpdf <- downloadHandler(
    filename = "report.pdf",
    content = function(file) {
    withProgress(message = 'Rendering, please wait!', {
        
      if(input$metadata=="Load"){
        tempReport <- file.path(tdir, "Load.Rmd")
        file.copy("./Scripts/Load.Rmd", tempReport, overwrite = TRUE)}
      
      if(input$metadata=="Boxplots"){
        tempReport <- file.path(tdir, "Boxplots.Rmd")
        file.copy("./Scripts/Boxplots.Rmd", tempReport, overwrite = TRUE)
        tempReport2 <- file.path(adir, "plotting_functions.R")
        file.copy("./Scripts/Accessories/plotting_functions.R", tempReport2, overwrite = TRUE)}
      
      if(input$metadata=="Lineplots"){
        tempReport <- file.path(tdir, "Lineplots.Rmd")
        file.copy("./Scripts/Lineplots.Rmd", tempReport, overwrite = TRUE)
        tempReport2 <- file.path(adir, "plotting_functions.R")
        file.copy("./Scripts/Accessories/plotting_functions.R", tempReport2, overwrite = TRUE)}
      
      if(input$metadata=="Barplots"){
        tempReport <- file.path(tdir, "Barplots.Rmd")
        file.copy("./Scripts/Barplots.Rmd", tempReport, overwrite = TRUE)
        tempReport2 <- file.path(adir, "plotting_functions.R")
        file.copy("./Scripts/Accessories/plotting_functions.R", tempReport2, overwrite = TRUE)}     
      
      if(input$metadata=="Dotcharts"){
        tempReport <- file.path(tdir, "Dotchart.Rmd")
        file.copy("./Scripts/Dotchart.Rmd", tempReport, overwrite = TRUE)
        tempReport2 <- file.path(adir, "plotting_functions.R")
        file.copy("./Scripts/Accessories/plotting_functions.R", tempReport2, overwrite = TRUE)}  
      
      if(input$metadata=="StackedBarArea"){
        tempReport <- file.path(tdir, "StackedBarArea.Rmd")
        file.copy("./Scripts/StackedBarArea.Rmd", tempReport, overwrite = TRUE)}
      
      params <- list(
        datamap = input$uploadmap,
        dataconfig = input$uploadconfig,
        inputstructure = input$inputstructure,
        metadata = input$metadata
      )
      flog.logger(name = 'ROOT', 
                  appender = appender.file('render.log'))
      rmarkdown::render(tempReport, output_file = file,
                        params = params,
                        envir = new.env(parent = globalenv())
      )
    })
   }
  )
  
  output$reporthtml <- downloadHandler(
    filename = "report.html",
    content = function(file) {
      withProgress(message = 'Rendering, please wait!', {
        
        if(input$metadata=="Load"){
          tempReport <- file.path(tdir, "Loadhtml.Rmd")
          file.copy("./Scripts/Loadhtml.Rmd", tempReport, overwrite = TRUE)}
        
        if(input$metadata=="Boxplots"){
          tempReport <- file.path(tdir, "Boxplotshtml.Rmd")
          file.copy("./Scripts/Boxplotshtml.Rmd", tempReport, overwrite = TRUE)
          tempReport2 <- file.path(adir, "plotting_functions.R")
          file.copy("./Scripts/Accessories/plotting_functions.R", tempReport2, overwrite = TRUE)}
        
        if(input$metadata=="Lineplots"){
          tempReport <- file.path(tdir, "Lineplotshtml.Rmd")
          file.copy("./Scripts/Lineplotshtml.Rmd", tempReport, overwrite = TRUE)
          tempReport2 <- file.path(adir, "plotting_functions.R")
          file.copy("./Scripts/Accessories/plotting_functions.R", tempReport2, overwrite = TRUE)}
        
        if(input$metadata=="Barplots"){
          tempReport <- file.path(tdir, "Barplotshtml.Rmd")
          file.copy("./Scripts/Barplotshtml.Rmd", tempReport, overwrite = TRUE)
          tempReport2 <- file.path(adir, "plotting_functions.R")
          file.copy("./Scripts/Accessories/plotting_functions.R", tempReport2, overwrite = TRUE)}     

        if(input$metadata=="Dotcharts"){
          tempReport <- file.path(tdir, "Dotcharthtml.Rmd")
          file.copy("./Scripts/Dotcharthtml.Rmd", tempReport, overwrite = TRUE)
          tempReport2 <- file.path(adir, "plotting_functions.R")
          file.copy("./Scripts/Accessories/plotting_functions.R", tempReport2, overwrite = TRUE)}     
        
        if(input$metadata=="StackedBarArea"){
          tempReport <- file.path(tdir, "StackedBarAreahtml.Rmd")
          file.copy("./Scripts/StackedBarAreahtml.Rmd", tempReport, overwrite = TRUE)}
                
        params <- list(
          datamap = input$uploadmap,
          dataconfig = input$uploadconfig,
          inputstructure = input$inputstructure,
          metadata = input$metadata
        )
        
        rmarkdown::render(tempReport, output_file = file,
                          params = params,
                          envir = new.env(parent = globalenv())
        )
      })
    }
  )
  
  
  output$files_zip_button <- downloadHandler(
    filename <- function() {
      paste("output", "tar", sep=".")
    },
    
    content <- function(file) {
      tdir = tempdir()
      tdir = paste(tdir,"\\Results",sep = "")
      tar(file, files = tdir)
    }
  ) 
  

}

shinyApp(ui, server)